
// Q2 (Conditionals & Operators) - Write an if-else statement that checks if a number stored in 
// variable marks is greater than or equal to 75. If yes, log "Distinction", else if greater than
//  or equal to 60 log "First Division", else log "Second Division". Test with marks = 82.

 let marks =82

 if(marks>=75){
    console.log("Distinction");
 }
else if (marks>=60) {
    console.log("First Division");
    
} else {
    console.log("Second");
    
}
    

// Q3 (Loops) - Use a for loop to print all numbers from 1 to 50 that are divisible by both
//  3 and 5.

for (let i = 0; i <=50 ; i++) {
    if(i % 3 == 0 && i % 5== 0 )
    console.log(i);
    
}

// Q1 (Variables & Data Types) - Create variables to store: your name (string), age (number), 
// isStudent (boolean), and favoriteFruit (assign it as null). Use typeof to log the data type
//  of each variable.Q1 (Variables & Data Types) - Create variables to store: your name (string),
//  age (number), isStudent (boolean), and favoriteFruit (assign it as null). Use typeof to log
//  the data type of each variable.

let name = "SOUMYA"
let age =   19
let isStudent = true
let favoriteFruit = null

console.log(typeof name);
console.log(typeof age);
console.log(typeof isStudent);
console.log(typeof favoriteFruit);

